# # __init__.py
from .snaggr import collect_hotel_google_reviews, collect_multiple_hotels_google_reviews